# eotr — iOS version (Eye's On The Road, pronounced otter) 🦦📱

> Same otter, same 10,000 ms rule, now for iPhone.

This is the **iPhone companion** to your Android `com.eotr.eyesontheroad` project. It uses the **exact same logic** (accelerometer + GPS + gyroscope + level check → 10s still to unlock) but is built with **iOS-native tools** (Xcode + Swift + SwiftUI + CoreMotion + CoreLocation).

## ⚠️ Honest iOS reality (like Android’s “unbreakable” talk)

**iPhone is even stricter than Android:**

| What you wanted (Android) | iOS reality |
|---------------------------|-------------|
| `SYSTEM_ALERT_WINDOW` overlay over any app while driving | **Not allowed.** No app can draw over other apps on iOS. Ever. |
| Foreground service that blocks unlocking | **Not allowed.** iOS won’t let any app prevent the user from going Home or opening other apps. |
| True unbreakable lock | **Only with MDM (business/school) or Screen Time FamilyControls.** Regular App Store apps can only create *friction*, not a jail. |

**What eotr *can* do on iPhone (and does, in this project):**
1. **Detect driving** with same 3 sensors (CoreMotion accelerometer + gyroscope, CoreLocation speed)
2. **Show a full-screen red Block Screen** *inside the eotr app* when moving — with countdown + Emergency SOS (always allowed)
3. **Use Apple’s *Screen Time* API (FamilyControls + DeviceActivity + ManagedSettings)** — with parent permission — to **actually shield other apps** (Messages, TikTok, etc.) while driving is detected. This is the *only* App-Store-allowed way to block other apps on iOS, and it requires the user/parent to explicitly authorize Screen Time. It’s friction, not ransomware — user can still override via Screen Time passcode, but it’s strong.
4. **Focus/Do Not Disturb Driving** integration + live notifications
5. **Background location** to keep detecting even when eotr is in background (with “Always Allow” location)

**MDM option (like Android Device Owner):** For a teen’s dedicated device or family fleet, enroll in Apple Business Manager / MDM (Jamf, Mosyle) → eotr can be a single-app lock. That *is* unbreakable, but only for supervised devices.

**Bottom line:** On iPhone, eotr is **best-effort + Screen Time shield** + MDM for truly unbreakable. Apple will reject any app that claims to “lock the phone” without using their approved APIs. We use the approved ones.

---

## Project structure (what’s in this zip)

```
eotr-ios/
├── Sources/
│   ├── eotrApp.swift                // App entry, background setup
│   ├── ContentView.swift             // Dashboard + perm checklist (like Android MainActivity)
│   ├── StationaryDetector.swift      // 10s rule engine — PORT of Android StationaryDetector.kt, same thresholds
│   ├── DrivingDetectionManager.swift // CoreMotion + CoreLocation fusion, 5 Hz loop, broadcasts to UI
│   ├── BlockView.swift               // Red otter block screen (like Android BlockActivity)
│   └── ScreenTimeManager.swift       // FamilyControls shield (iOS 16+) — optional but strongest
├── Resources/
│   ├── ic_otter_mascot.png           // same otter floating with phone
│   └── AppIcon assets (1024x1024)
├── README-iOS.md (this)
├── BUILD_GUIDE-iOS.md
└── Info.plist snippet + entitlements
```

Same logic, same thresholds, same otter — just Swift.

---

## Quick start

### 1. Create Xcode project (2 min)
1. Open **Xcode 15+** on Mac (macOS 14+)
2. File → New → Project → iOS → App → SwiftUI → name: `eotr`, bundle: `com.eotr.eyesontheroad`, min iOS 16.0
3. Drag all files from `Sources/` into Xcode project (check “Copy if needed”)
4. Drag `ic_otter_mascot.png` into Assets.xcassets → AppIcon

### 2. Capabilities to enable (Xcode → Signing & Capabilities)
- **Background Modes:** Location updates + Background fetch
- **Family Controls** (for app shielding) — requires Apple Developer Program ($99/yr) + FamilyControls entitlement request in App Store Connect
- **Maps** (if you want map preview)

### 3. Info.plist keys (already in snippet, just confirm)
- `NSLocationWhenInUseUsageDescription` → “eotr detects driving via GPS to lock screen for safety”
- `NSLocationAlwaysAndWhenInUseUsageDescription` → “eotr needs always location to detect driving even in background”
- `NSMotionUsageDescription` → “eotr uses motion sensors to detect if phone is on level surface”

### 4. Run
- Select your iPhone (iOS 16+) → Run ▶️
- Grant: Location → **Always Allow** + Precise ON, Motion, Notifications
- Screen Time shield: tap Enable FamilyControls → approve → select apps to shield while driving (e.g., Messages, Snapchat)
- Put phone flat & still 10s → “Protection Active” green. Walk/drive → red block inside eotr + shield activates for selected apps.

### Without Screen Time (works, but weaker)
If you skip FamilyControls approval, eotr still works inside its own app — it will show the red block and notification, but **won’t shield other apps**. User can just swipe to Messages. That’s Apple’s limit. Still useful as a reminder, but not enforcement.

---

## Same tools contract — iOS side

**Canonical iOS toolchain (we both use this):**
- **IDE:** Xcode 15+ (you locally on Mac, I generate Swift sources here)
- **Language:** Swift 5.9, SwiftUI, iOS 16.0+ (for FamilyControls)
- **Sensors:** `CMMotionManager` (accelerometer 50 Hz, gyro 50 Hz) + `CLLocationManager` (kCLLocationAccuracyBest, 1s)
- **Blocking:** `FamilyControls` + `DeviceActivity` + `ManagedSettings` (shield apps) OR `Focus` API
- **Background:** `CLLocationManager` always + `BGTaskScheduler`
- **Same thresholds:** `|mag-9.81|<0.9`, `var<0.35`, `gyro<0.12`, `speed<0.5 m/s`, `tilt<15°`, `10,000 ms`

You build the IPA locally (`Product → Archive → Distribute App`). I generate the correct sources so your local build succeeds — same collaboration as Android.

---

## Shared Hub

Everything (Android + iOS) lives in the same Drive folder:
📁 https://drive.google.com/drive/folders/1q-gWovIsOkV1cqrfH-rip1DwpP9OhH4T
- `EOTR_MASTER_HUB.md` — updated with iOS section, still your ONE link to paste
- `eotr-android-project.zip` — Android
- `eotr-ios-project.zip` — this iOS project (after you download below)

We keep one hub, two platforms, same logic.

---

## App Store warning

Apple will **reject** if:
- You claim “prevents phone unlocking” without using FamilyControls/ManagedSettings
- You try to hide the Screen Time prompt or auto-select all apps

Do:
- Onboarding: explain why you need Screen Time + show which apps will be shielded
- Let user choose which apps to shield (don’t auto-shield Phone)
- Never block Phone/SOS — those are always shield-exception

See `BUILD_GUIDE-iOS.md` for review notes.

---

Built for Delaware — test in parking lot first, never while driving! 🦦
