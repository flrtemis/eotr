# BUILD GUIDE — eotr iOS (iPhone)

Same tools contract, iPhone side.

## Prereqs (your Mac)

- **Mac** with macOS 14+ (Sonoma) + **Xcode 15.2+**
- Apple Developer Program ($99/yr) — only needed for Screen Time shielding & TestFlight/App Store. Without it, you can still run on your own iPhone free (7-day cert).
- iPhone 12+ with iOS 16+ (FamilyControls requires iOS 16)

## Create project (2 min)

```bash
# Unzip hub file
unzip eotr-ios-project.zip -d ~/eotr-ios
open ~/eotr-ios
```

1. Xcode → File → New → Project → iOS → App
   - Product: `eotr`
   - Interface: SwiftUI
   - Language: Swift
   - Bundle ID: `com.eotr.eyesontheroad` (same as Android)
   - Deployment Target: iOS 16.0

2. Copy Sources: drag `Sources/*.swift` into Xcode (Copy items if needed, Add to targets: eotr)

3. Add icon: `Resources/ic_otter_mascot.png` → Assets.xcassets → AppIcon (make 1024x1024 export from the PNG)

4. **Capabilities** (Signing & Capabilities → + Capability):
   - Background Modes → check Location updates, Background fetch
   - Family Controls → ON (this triggers entitlement request — see below)

5. **Info.plist** — add these keys (Xcode → Info tab):
   ```xml
   <key>NSLocationWhenInUseUsageDescription</key><string>eotr detects driving via GPS to shield screen for safety</string>
   <key>NSLocationAlwaysAndWhenInUseUsageDescription</key><string>eotr needs always location to detect driving even in background</string>
   <key>NSMotionUsageDescription</key><string>eotr uses accelerometer & gyroscope to detect level & stillness</string>
   <key>UIBackgroundModes</key><array><string>location</string><string>fetch</string></array>
   ```

## FamilyControls entitlement (for shielding other apps)

Without this, eotr still works but only inside eotr (cannot shield Messages etc.)

1. Go to https://developer.apple.com/contact/request/family-controls-distribution
2. Request entitlement with reason: “Safety app that shields distracting apps while driving is detected via motion+GPS; uses FamilyControls + DeviceActivity to enforce 10s still-and-level rule. Never blocks Phone/SOS.”
3. Apple emails you — you add the entitlement file to provisioning profile.
4. In Xcode, enable FamilyControls capability — it will show as green once approved.

**For quick testing without approval:** just run — the block screen inside eotr works immediately. Shielding other apps will log “FamilyControls not available” and skip.

## Build & Run

- Select your iPhone as destination (not simulator — simulator has fake GPS/motion)
- Product → Run (Cmd+R)
- On iPhone: allow Location → **Always Allow** + Precise Location ON
- Allow Motion & Fitness
- Tap Enable Protection → if you did FamilyControls picker, select apps to shield (Messages, Snapchat, Safari, etc. — do NOT select Phone)

Test:
- Put phone flat on table still 10s → green “Protection Active”
- Pick up and walk → red BlockView slides up, notification “Driving detected — apps shielded”
- Put flat 10s → shields lift automatically, BlockView dismisses
- Try opening Messages while shielded → iOS shows “Time Limit” shield screen (you can enter Screen Time passcode to override — Apple requires this override)

## Archive IPA (to share like Android APK)

- Product → Archive → Distribute App → Ad Hoc or TestFlight
- IPA is at `~/Library/Developer/Xcode/Archives/...` — share via TestFlight or Diawi

## Troubleshooting iOS

- **GPS always red?** Go outside, open Maps to get fix. Indoor accuracy >30m → treated as not-still (fail-safe, same as Android)
- **Motion red?** Settings → Privacy → Motion & Fitness → eotr ON; also iPhone must be on iOS 16+
- **Shield not blocking?** You didn’t authorize FamilyControls or didn’t pick apps. Go to eotr → Enable FamilyControls → pick apps.
- **App killed in background?** Enable Always location + Background Modes. iOS is more aggressive than Android — but Significant Location Changes keeps eotr alive.
- **Want unbreakable?** Enroll device in Apple Business Manager MDM (Mosyle, Jamf) → restrict exiting eotr.

## Unified hub

Both Android + iOS zips live in same Drive hub:
https://drive.google.com/drive/folders/1q-gWovIsOkV1cqrfH-rip1DwpP9OhH4T
Update `EOTR_MASTER_HUB.md` when you change thresholds so both platforms stay in sync.
