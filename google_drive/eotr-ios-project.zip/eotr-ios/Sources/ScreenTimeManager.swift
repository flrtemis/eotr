import Foundation
import Combine

// MARK: - ScreenTimeManager — the ONLY App-Store-allowed way to shield other apps on iOS
// Requires: iOS 16+, FamilyControls entitlement, user approval via AuthorizationCenter.
// If entitlement not present, this manager no-ops gracefully (eotr still works inside its own app).

#if canImport(FamilyControls)
import FamilyControls
import ManagedSettings
import DeviceActivity

@MainActor
final class ScreenTimeManager: ObservableObject {
    static let shared = ScreenTimeManager()

    private let center = AuthorizationCenter.shared
    private let store = ManagedSettingsStore()
    // DeviceActivity for scheduling shields is more involved — for v1 we do simple immediate shield.
    // To shield, we need user's selected apps (from FamilyActivityPicker). We store tokens.

    @Published var isAuthorized = false
    @Published var shieldedTokens: Set<ApplicationToken> = []

    private init() {
        Task { await refreshStatus() }
    }

    func refreshStatus() async {
        isAuthorized = center.authorizationStatus == .approved
    }

    func requestAuthorization() async throws {
        try await center.requestAuthorization(for: .individual)
        isAuthorized = center.authorizationStatus == .approved
    }

    // Call with tokens from a FamilyActivityPicker in ContentView (not included here to keep zip small)
    // Example: user picks Messages, TikTok, etc. We save tokens.
    func setShieldedApps(tokens: Set<ApplicationToken>) {
        shieldedTokens = tokens
        // Persist for relaunch
        if let data = try? JSONEncoder().encode(tokens) {
            UserDefaults.standard.set(data, forKey: "eotr_shield_tokens")
        }
    }

    func activateShield() {
        guard isAuthorized, !shieldedTokens.isEmpty else { return }
        // Shield selected apps
        store.shield.applications = shieldedTokens
        // Optionally shield categories/web
        // store.shield.applicationCategories = .all()
        // Shield UI customization
        store.shield.applicationShieldRestriction = .none
    }

    func deactivateShield() {
        guard isAuthorized else { return }
        store.shield.applications = nil
        store.shield.applicationCategories = nil
        store.shield.webDomainCategories = nil
    }
}

#else
// Fallback when FamilyControls not available (simulator or no entitlement) — no-op with log
@MainActor
final class ScreenTimeManager: ObservableObject {
    static let shared = ScreenTimeManager()
    @Published var isAuthorized = false
    @Published var isShielding = false
    func requestAuthorization() async throws { print("FamilyControls not available in this build — add entitlement in Xcode Capabilites") }
    func activateShield() { print("Shield requested but FamilyControls entitlement missing — eotr will only block inside its own app") }
    func deactivateShield() {}
}
#endif
