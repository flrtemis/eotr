import Foundation
import CoreMotion
import CoreLocation
import Combine

// MARK: - DrivingDetectionManager — fuses accel + gyro + GPS on iOS, same 5 Hz loop as Android
final class DrivingDetectionManager: NSObject, ObservableObject, CLLocationManagerDelegate {

    @Published var decision: StationaryDecision?
    @Published var accelMag: Float = 0
    @Published var gyroMag: Float = 0
    @Published var speedMps: Float = 0
    @Published var accuracyM: Float = 999
    @Published var tiltDeg: Float = 90
    @Published var isBlocking: Bool = false // true = driving, should show block

    private let motion = CMMotionManager()
    private let locationManager = CLLocationManager()
    private let detector = StationaryDetector()
    private var timer: Timer?

    // Latest raw
    private var lastAx = 0.0, lastAy = 0.0, lastAz = 9.81
    private var lastGx = 0.0, lastGy = 0.0, lastGz = 0.0
    private var lastSpeed: Float = 0
    private var lastAcc: Float = 999

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 3
        locationManager.allowsBackgroundLocationUpdates = true
        locationManager.pausesLocationUpdatesAutomatically = false
    }

    func start() {
        // Motion
        if motion.isAccelerometerAvailable {
            motion.accelerometerUpdateInterval = 1.0/50.0
            motion.startAccelerometerUpdates(to: .main) { [weak self] data, _ in
                guard let d = data else { return }
                self?.lastAx = d.acceleration.x * 9.81
                self?.lastAy = d.acceleration.y * 9.81
                self?.lastAz = d.acceleration.z * 9.81
            }
        }
        if motion.isGyroAvailable {
            motion.gyroUpdateInterval = 1.0/50.0
            motion.startGyroUpdates(to: .main) { [weak self] data, _ in
                guard let d = data else { return }
                self?.lastGx = d.rotationRate.x
                self?.lastGy = d.rotationRate.y
                self?.lastGz = d.rotationRate.z
            }
        }
        // Also use deviceMotion for better gravity separation (optional)
        if motion.isDeviceMotionAvailable {
            motion.deviceMotionUpdateInterval = 1.0/50.0
            motion.startDeviceMotionUpdates()
        }

        // Location
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        locationManager.startMonitoringSignificantLocationChanges()

        // 5 Hz eval loop, like Android
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in
            self?.evaluate()
        }
        RunLoop.main.add(timer!, forMode: .common)
    }

    func stop() {
        timer?.invalidate(); timer = nil
        motion.stopAccelerometerUpdates()
        motion.stopGyroUpdates()
        motion.stopDeviceMotionUpdates()
        locationManager.stopUpdatingLocation()
        detector.reset()
    }

    func requestPermissions() {
        locationManager.requestWhenInUseAuthorization()
        // Call this on button: locationManager.requestAlwaysAuthorization()
    }

    // MARK: eval
    private func evaluate() {
        // Prefer deviceMotion gravity-corrected accel if available
        if let dm = motion.deviceMotion {
            // userAcceleration is without gravity — we want total accel magnitude including gravity
            // So use dm.gravity + dm.userAcceleration
            let ax = dm.gravity.x * 9.81 + dm.userAcceleration.x * 9.81
            let ay = dm.gravity.y * 9.81 + dm.userAcceleration.y * 9.81
            let az = dm.gravity.z * 9.81 + dm.userAcceleration.z * 9.81
            lastAx = ax; lastAy = ay; lastAz = az
            lastGx = dm.rotationRate.x; lastGy = dm.rotationRate.y; lastGz = dm.rotationRate.z
        }

        accelMag = detector.accelMagnitude(ax: lastAx, ay: lastAy, az: lastAz)
        gyroMag = detector.gyroMagnitude(gx: lastGx, gy: lastGy, gz: lastGz)
        tiltDeg = detector.tiltDegrees(ax: lastAx, ay: lastAy, az: lastAz)
        speedMps = lastSpeed
        accuracyM = lastAcc

        let snap = SensorSnapshot(
            accelMagnitude: accelMag,
            gyroMagnitude: gyroMag,
            gpsSpeedMps: speedMps,
            gpsAccuracyM: accuracyM,
            tiltDegrees: tiltDeg
        )
        let d = detector.update(snap)
        decision = d
        let shouldBlock = !d.allStill
        if shouldBlock != isBlocking {
            isBlocking = shouldBlock
            // Trigger shield via ScreenTimeManager if available
            if shouldBlock {
                ScreenTimeManager.shared.activateShield()
            } else {
                ScreenTimeManager.shared.deactivateShield()
            }
        }
    }

    // MARK: CLLocationDelegate
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.last else { return }
        // speed is m/s, may be -1 if unavailable
        let s = loc.speed >= 0 ? Float(loc.speed) : 0
        lastSpeed = s
        lastAcc = Float(loc.horizontalAccuracy)
    }
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse {
            manager.startUpdatingLocation()
        }
    }
}
