import SwiftUI

@main
struct eotrApp: App {
    // Request background location + motion on launch if user already approved
    init() {
        // Needed for background location blue bar control
        // Info.plist must include UIBackgroundModes = location
    }
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
