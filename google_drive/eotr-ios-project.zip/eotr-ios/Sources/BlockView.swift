import SwiftUI

struct BlockView: View {
    @ObservedObject var manager: DrivingDetectionManager
    @Environment(\.dismiss) var dismiss

    var body: some View {
        ZStack {
            Color.red.ignoresSafeArea()
            VStack(spacing: 16) {
                Image("ic_otter_mascot").resizable().scaledToFit().frame(width: 110, height: 110).background(Color.white).clipShape(Circle()).shadow(radius: 6).padding(.top, 24)
                Text("🦦 eotr").font(.title3.bold()).foregroundColor(.white)
                Text("Eyes on the road.").font(.system(size: 28, weight: .black, design: .rounded)).foregroundColor(.white).multilineTextAlignment(.center)
                Text("Your phone is moving. For your safety, other apps are shielded.").font(.subheadline).foregroundColor(.white.opacity(0.9)).multilineTextAlignment(.center).padding(.horizontal, 32)

                VStack(spacing: 10) {
                    Text("🚗 MOVEMENT DETECTED").font(.caption.bold()).foregroundColor(.red)
                    if let d = manager.decision {
                        Text("Unlocks after 10 seconds of being still on a level surface…").font(.caption).foregroundColor(.primary).multilineTextAlignment(.center)
                        ProgressView(value: Double(10000 - d.remainingMsToUnlock), total: 10000).tint(.red)
                        Text(String(format: "%.1fs still needed", Double(d.remainingMsToUnlock)/1000)).font(.title2.bold()).foregroundColor(.red)
                        Text(sensorSummary(d)).font(.caption2).foregroundColor(.secondary).padding(6).background(Color.gray.opacity(0.1)).cornerRadius(6)
                    }
                }.padding().background(Color.white).cornerRadius(20).shadow(radius: 8).padding(.horizontal, 24)

                Button(action: emergency) {
                    Label("Emergency SOS", systemImage: "phone.fill").bold().frame(maxWidth: .infinity).padding().background(Color.white).foregroundColor(.red).cornerRadius(16).padding(.horizontal, 24)
                }
                Text("Emergency SOS bypasses eotr — always allowed.").font(.caption2).foregroundColor(.white.opacity(0.8))

                Button(action: { showPassengerDialog = true }) {
                    Text("I’m a Passenger").font(.caption).frame(maxWidth: .infinity).padding(.vertical, 12).background(Color.clear).overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white)).foregroundColor(.white).padding(.horizontal, 24)
                }
                Text("Inspiration: keep Eyes On The Road — eotr = Eye’s On The Road, pronounced otter 🦦").font(.caption2).foregroundColor(.white.opacity(0.8)).multilineTextAlignment(.center).padding(.horizontal, 24).padding(.top, 8)
                Spacer()
            }
        }
        .interactiveDismissDisabled(manager.isBlocking) // can't swipe away while moving — same as Android back-block
        .alert("Passenger verification", isPresented: $showPassengerDialog) {
            Button("I understand — place flat & wait", role: .cancel) {}
        } message: {
            Text("This exists so passengers aren’t stranded. If you are the driver, keep your eyes on the road. To relax, place phone flat & completely still for 10 seconds. Do not attempt while driving.")
        }
    }

    @State private var showPassengerDialog = false

    func emergency() {
        // SOS — iOS will handle, we just open phone dialer. Better: trigger SOS via managed setting is not allowed, so we open tel://
        if let url = URL(string: "tel://911") { UIApplication.shared.open(url) }
    }
    func sensorSummary(_ d: StationaryDecision) -> String {
        var s = ""
        s += d.isAccelStill ? "Accel: ✓ " : "Accel: ✗ "
        s += d.isGyroStill ? "Gyro: ✓ " : "Gyro: ✗ "
        s += d.isGpsStill ? "GPS: ✓ " : "GPS: ✗ "
        s += d.isLevel ? "Level: ✓ " : "Level: ✗ "
        s += " • \(d.reason)"
        return s
    }
}
