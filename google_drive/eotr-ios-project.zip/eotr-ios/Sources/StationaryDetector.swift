import Foundation
import CoreMotion

// MARK: - EOTR Core Rule — iOS Port of Android StationaryDetector.kt
// Same thresholds, same logic, same 10,000 ms contract.
// Both Android and iOS must agree or we have platform drift.

struct SensorSnapshot {
    var accelMagnitude: Float = 0
    var gyroMagnitude: Float = 0
    var gpsSpeedMps: Float = 0
    var gpsAccuracyM: Float = 999
    var tiltDegrees: Float = 90
    var timestampMs: Int64 = Int64(Date().timeIntervalSince1970 * 1000)
}

struct StationaryDecision {
    var isAccelStill: Bool
    var isGyroStill: Bool
    var isGpsStill: Bool
    var isLevel: Bool
    var allStill: Bool // true only when allStill && duration >= 10s
    var stationaryDurationMs: Int64
    var remainingMsToUnlock: Int64
    var reason: String
}

final class StationaryDetector: ObservableObject {

    static let requiredStationaryMs: Int64 = 10_000

    // Same thresholds as Android
    static let accelGravity: Float = 9.80665
    static let accelTolerance: Float = 0.9
    static let accelVarianceMax: Float = 0.35
    static let gyroStillMax: Float = 0.12
    static let gpsStillMaxMps: Float = 0.5
    static let gpsMaxAccuracyM: Float = 30
    static let levelMaxTiltDeg: Float = 15

    private var accelWindow: [Float] = []
    private var stationaryStartMs: Int64?
    @Published var lastDecision: StationaryDecision?

    func update(_ snap: SensorSnapshot) -> StationaryDecision {
        // variance window
        accelWindow.append(snap.accelMagnitude)
        if accelWindow.count > 20 { accelWindow.removeFirst() }
        let variance: Float = {
            guard accelWindow.count >= 5 else { return 99 }
            let avg = accelWindow.reduce(0, +) / Float(accelWindow.count)
            let v = accelWindow.map { ($0 - avg) * ($0 - avg) }.reduce(0, +) / Float(accelWindow.count)
            return v
        }()

        let accelStill = isAccelerometerStill(mag: snap.accelMagnitude, variance: variance)
        let gyroStill = snap.gyroMagnitude < Self.gyroStillMax
        let gpsStill = isGpsStill(speed: snap.gpsSpeedMps, accuracy: snap.gpsAccuracyM)
        let level = snap.tiltDegrees < Self.levelMaxTiltDeg

        let allSensorsStill = accelStill && gyroStill && gpsStill && level
        let now = snap.timestampMs
        if allSensorsStill {
            if stationaryStartMs == nil { stationaryStartMs = now }
        } else {
            stationaryStartMs = nil
        }
        let duration: Int64 = stationaryStartMs != nil ? now - stationaryStartMs! : 0
        let remaining: Int64 = allSensorsStill ? max(0, Self.requiredStationaryMs - duration) : Self.requiredStationaryMs

        let reason = buildReason(accelStill: accelStill, gyroStill: gyroStill, gpsStill: gpsStill, level: level, variance: variance, snap: snap)
        let decision = StationaryDecision(
            isAccelStill: accelStill, isGyroStill: gyroStill, isGpsStill: gpsStill, isLevel: level,
            allStill: allSensorsStill && duration >= Self.requiredStationaryMs,
            stationaryDurationMs: duration, remainingMsToUnlock: remaining, reason: reason
        )
        lastDecision = decision
        return decision
    }

    func reset() {
        stationaryStartMs = nil
        accelWindow.removeAll()
        lastDecision = nil
    }

    var isUnlockAllowed: Bool { lastDecision?.allStill == true }

    // MARK: helpers
    private func isAccelerometerStill(mag: Float, variance: Float) -> Bool {
        return abs(mag - Self.accelGravity) < Self.accelTolerance && variance < Self.accelVarianceMax
    }
    private func isGpsStill(speed: Float, accuracy: Float) -> Bool {
        if accuracy > Self.gpsMaxAccuracyM { return false } // fail-safe, same as Android
        return speed < Self.gpsStillMaxMps
    }
    private func buildReason(accelStill: Bool, gyroStill: Bool, gpsStill: Bool, level: Bool, variance: Float, snap: SensorSnapshot) -> String {
        if accelStill && gyroStill && gpsStill && level { return "All sensors confirm stationary & level" }
        var fails: [String] = []
        if !accelStill { fails.append("Accel moving (var \(String(format:"%.2f", variance)))") }
        if !gyroStill { fails.append("Gyro rotating (\(String(format:"%.2f", snap.gyroMagnitude)) rad/s)") }
        if !gpsStill { fails.append("GPS moving (\(String(format:"%.1f", snap.gpsSpeedMps*3.6)) km/h)") }
        if !level { fails.append("Not level (\(String(format:"%.0f", snap.tiltDegrees))° tilt)") }
        return fails.joined(separator: " • ")
    }

    // MARK: math
    func accelMagnitude(ax: Double, ay: Double, az: Double) -> Float {
        return Float(sqrt(ax*ax + ay*ay + az*az))
    }
    func tiltDegrees(ax: Double, ay: Double, az: Double) -> Float {
        let mag = sqrt(ax*ax + ay*ay + az*az)
        guard mag != 0 else { return 90 }
        let cosTheta = (az / mag).clamped(to: -1...1)
        return Float(acos(cosTheta) * 180 / .pi)
    }
    func gyroMagnitude(gx: Double, gy: Double, gz: Double) -> Float {
        return Float(sqrt(gx*gx + gy*gy + gz*gz))
    }
}

fileprivate extension Double {
    func clamped(to range: ClosedRange<Double>) -> Double { min(max(self, range.lowerBound), range.upperBound) }
}
