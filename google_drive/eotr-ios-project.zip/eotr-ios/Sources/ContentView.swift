import SwiftUI

struct ContentView: View {
    @StateObject private var manager = DrivingDetectionManager()
    @State private var showingBlock = false

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    // Header
                    VStack(spacing: 8) {
                        Image("ic_otter_mascot")
                            .resizable().scaledToFit().frame(width: 120, height: 120)
                            .background(Color.white).clipShape(Circle()).shadow(radius: 6)
                        Text("eotr").font(.system(size: 34, weight: .black, design: .rounded)).foregroundColor(Color(red: 0.01, green: 0.53, blue: 0.82)).tracking(2)
                        Text("Eye's On The Road").font(.caption.bold()).foregroundColor(.brown)
                        Text("pronounced “otter” — keep your eyes on the road").font(.caption2).foregroundColor(.secondary)
                        StatusChip(isBlocking: manager.isBlocking, decision: manager.decision)
                        if let d = manager.decision {
                            Text(d.allStill ? "✓ Phone is level & stationary — eotr relaxed" : (d.remainingMsToUnlock > 0 && d.remainingMsToUnlock < 10000 ? "⏱ Waiting 10s of stillness to relax…" : "⊘ Movement detected — shield active"))
                                .font(.caption2).foregroundColor(.secondary).multilineTextAlignment(.center)
                        }
                    }.padding().background(Color.white).cornerRadius(24).shadow(color: .black.opacity(0.06), radius: 8)

                    // Live sensors
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Live sensor check (All 3 must agree)").font(.caption.bold())
                        Text("Phone must pass ALL 3 + stay flat & still for 10,000 ms to relax.").font(.caption2).foregroundColor(.secondary)
                        SensorRow(name: "Accelerometer", value: String(format: "%.2f m/s² %@", manager.accelMag, (manager.decision?.isAccelStill ?? false) ? "✓ still" : "✗ moving"), ok: manager.decision?.isAccelStill ?? false)
                        Divider()
                        SensorRow(name: "Gyroscope", value: String(format: "%.2f rad/s %@", manager.gyroMag, (manager.decision?.isGyroStill ?? false) ? "✓ still" : "✗ rotating"), ok: manager.decision?.isGyroStill ?? false)
                        Divider()
                        SensorRow(name: "GPS", value: String(format: "%.1f m/s (%.1f mph) %@", manager.speedMps, manager.speedMps*2.23694, (manager.decision?.isGpsStill ?? false) ? "✓ stationary" : "✗ moving"), ok: manager.decision?.isGpsStill ?? false)
                        Divider()
                        SensorRow(name: "Level", value: String(format: "%.0f° tilt %@", manager.tiltDeg, (manager.decision?.isLevel ?? false) ? "✓ level" : "✗ not level"), ok: manager.decision?.isLevel ?? false)
                        Divider()
                        HStack {
                            Text("Stationary timer").font(.caption.bold())
                            Spacer()
                            ProgressView(value: Double(10000 - (manager.decision?.remainingMsToUnlock ?? 10000)), total: 10000).tint(Color(red: 0.01, green: 0.53, blue: 0.82))
                            Text(String(format: "%.1fs / 10.0s", Double(10000 - (manager.decision?.remainingMsToUnlock ?? 10000))/1000)).font(.caption2.bold()).foregroundColor(Color(red: 0.01, green: 0.53, blue: 0.82))
                        }
                        Text("Logic: RELAX only after 10s continuous stationary + level. Otherwise SHIELD — Eyes on the road!").font(.caption2).foregroundColor(.secondary).padding(8).background(Color(red: 1, green: 0.97, blue: 0.88)).cornerRadius(8)
                    }.padding().background(Color.white).cornerRadius(20).overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.gray.opacity(0.15)))

                    // Checklist
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Setup checklist").font(.subheadline.bold())
                        ChecklistRow(title: "Location (Always Allow + Precise)", desc: "Needed for speed. GPS >1.5 mph = driving. Must be Always for background.")
                        ChecklistRow(title: "Motion & Fitness", desc: "Accelerometer + gyroscope. iOS Settings → Privacy → Motion & Fitness → eotr ON")
                        ChecklistRow(title: "Screen Time Shield (strongest)", desc: "FamilyControls to shield other apps while driving. Optional but this is the only App-Store-allowed way to block Messages/TikTok.")
                        ChecklistRow(title: "Notifications", desc: "Live ‘Protection Active’ banner while driving.")
                    }.padding().background(Color.white).cornerRadius(16).overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.gray.opacity(0.15)))

                    Button(action: { manager.start() }) {
                        Text(manager.isBlocking ? "🛡️ Shield Active — Monitoring" : "Enable Protection").bold().frame(maxWidth: .infinity).padding().background(Color(red: 0.01, green: 0.53, blue: 0.82)).foregroundColor(.white).cornerRadius(16)
                    }
                    Button(action: { showingBlock = true }) {
                        Text("Test Block Screen (preview)").frame(maxWidth: .infinity).padding().background(Color.white).overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.gray)).foregroundColor(.primary).cornerRadius(16)
                    }
                    VStack(alignment: .leading, spacing: 6) {
                        Text("About “unbreakable” on iPhone").font(.caption.bold()).foregroundColor(.red)
                        Text("iOS apps can’t draw over other apps or prevent Home. eotr uses Apple’s Screen Time FamilyControls to shield selected apps while driving — you must authorize it. Without it, eotr still warns inside its own app, but won’t block other apps. MDM (business) is the only truly unbreakable mode on both Android and iOS. Emergency SOS is never blocked.").font(.caption2).foregroundColor(.secondary)
                        Text("In emergency, press Side Button x5 for SOS — eotr never blocks SOS.").font(.caption2.bold()).foregroundColor(.green)
                    }.padding().background(Color.white).cornerRadius(16).overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.red.opacity(0.3)))

                    VStack(alignment: .leading) {
                        Text("How it works — 10,000 ms rule").font(.caption.bold())
                        Text("1) Accel mag ~9.81, low variance\n2) Gyro <0.12 rad/s\n3) GPS <0.5 m/s & <30m\n4) Tilt <15°\nAll TRUE 10s → RELAX. Any fail → SHIELD.").font(.caption2).foregroundColor(.secondary)
                    }.padding().background(Color.white).cornerRadius(12)

                    Text("Built for Delaware • v1.0.0-otter • com.eotr.eyesontheroad").font(.caption2).foregroundColor(.secondary)
                }.padding()
            }.background(Color(red: 0.96, green: 0.94, blue: 0.90))
            .navigationBarHidden(true)
            .onAppear { manager.requestPermissions() }
            .onChange(of: manager.isBlocking) { blocking in
                if blocking { showingBlock = true } else { showingBlock = false }
            }
            .sheet(isPresented: $showingBlock) {
                BlockView(manager: manager)
            }
        }
    }
}

struct StatusChip: View {
    var isBlocking: Bool
    var decision: StationaryDecision?
    var body: some View {
        Text(isBlocking ? "SHIELDING — MOVING" : "PROTECTION ACTIVE")
            .font(.caption2.bold()).foregroundColor(.white).padding(.horizontal, 14).padding(.vertical, 6)
            .background(isBlocking ? Color.red : Color.green).cornerRadius(20)
    }
}
struct SensorRow: View {
    var name: String; var value: String; var ok: Bool
    var body: some View {
        HStack { Text(name).font(.caption).frame(width: 110, alignment: .leading); Spacer(); Text(value).font(.caption2).foregroundColor(ok ? .green : .red); Circle().fill(ok ? Color.green : Color.red).frame(width: 10, height: 10) }
    }
}
struct ChecklistRow: View {
    var title: String; var desc: String
    var body: some View {
        VStack(alignment: .leading, spacing: 2) { Text(title).font(.caption.bold()); Text(desc).font(.caption2).foregroundColor(.secondary) }.padding(.vertical, 4)
    }
}
