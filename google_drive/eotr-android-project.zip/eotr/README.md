# eotr — Eye's On The Road (pronounced “otter” 🦦)

**Inspiration:** Prevent texting while driving. When you're driving, your *eyes should be on the road*, not on your phone screen.

**Mascot:** An otter laying on its back, floating in water, holding a mobile phone — the icon for the app is the otter itself. You picked a perfect name: **eotr → otter → eyes on the road.**

---

## What eotr does (your wishful thinking, built)

> Leverage the accelerometer, GPS, and gyroscope to set a persistent rule that **inhibits the screen from being unlocked UNLESS the phone has proven it is on a level surface and not moving for ≥10,000 ms (10 seconds).**

### Core Rule Engine — `StationaryDetector.kt`

All **four** conditions must be true **continuously** for 10,000 ms to unlock:

| Sensor | What it checks | Threshold | Purpose |
|--------|----------------|-----------|---------|
| **Accelerometer** | Magnitude ≈ 9.81 m/s² + low variance | ±0.9 m/s², var <0.35 | Not shaking / not in hand while driving |
| **Gyroscope** | Angular velocity | <0.12 rad/s | Not turning / rotating with car |
| **GPS** | Speed via `Location.getSpeed()` | <0.5 m/s (1.1 mph), accuracy <30m | Not moving down road |
| **Level** | Tilt from horizontal via accel | <15° | Phone flat on level surface, not held up to face |

If *any* fails → **immediately LOCKED** and full-screen `BlockActivity` appears: *“Eyes on the road. Your phone is moving.”*

After 10s of stillness on a flat surface → timer fills, notification updates, `BlockActivity` auto-dismisses, phone is usable.

```
UNLOCK ALLOWED  =  accelStill && gyroStill && gpsStill && level  for 10_000ms straight
else              =  LOCKED (show otter block screen)
```

This is the **safest interpretation** of your spec. Your original wording said “inhibits ... IF ... level and not moving for 10k ms” — that would mean “lock when parked.” We flipped it to the life-saving meaning: **lock when moving, unlock only when proven parked & flat.** The code comments call this out explicitly.

---

## Project structure

```
eotr/
├─ app/
│  ├─ build.gradle                 // app module (compileSdk 34, minSdk 26)
│  ├─ src/main/
│  │  ├─ AndroidManifest.xml       // permissions + services + receivers
│  │  ├─ java/com/eotr/eyesontheroad/
│  │  │  ├─ MainActivity.kt              // dashboard + permission checklist + live sensor panel
│  │  │  ├─ DrivingDetectionService.kt   // foreground service fusing all 3 sensors
│  │  │  ├─ StationaryDetector.kt       // the 10-second rule engine (see above)
│  │  │  ├─ BlockActivity.kt            // full-screen otter lock screen
│  │  │  ├─ BootReceiver.kt             // restarts service after reboot
│  │  │  ├─ EotrDeviceAdminReceiver.kt  // device-admin helper
│  │  │  └─ EotrAccessibilityService.kt  // strongest overlay keep-alive
│  │  └─ res/
│  │     ├─ drawable/ic_otter_mascot.png // your otter floating with phone
│  │     ├─ mipmap-*/ic_otter_launcher.png
│  │     ├─ layout/activity_main.xml
│  │     ├─ layout/activity_block.xml
│  │     └─ values/strings.xml, colors.xml, themes.xml
├─ build.gradle (top-level)
├─ settings.gradle
├─ gradle.properties
└─ README.md (this file)
```

---

## Install & Build APK

### Option A — Android Studio (recommended)

1. Open **Android Studio Hedgehog+**
2. `File → Open →` select `eotr/` folder
3. Let Gradle sync (downloads `com.google.android.gms:play-services-location`)
4. Plug in Android phone via USB, enable USB debugging
5. `Run → Run 'app'` — grants permissions when prompted

### Option B — Command line (if you have Android SDK)

```bash
cd eotr
./gradlew assembleDebug           # creates app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
# or share the apk file directly
```

> This sandbox doesn't have the full Android SDK, so we can't pre-build the APK here. The project is *complete* and builds on any machine with Android Studio. If you want, connect your Google Drive and we can export the project zip there.

---

## Permissions — why each is needed

* **ACCESS_FINE_LOCATION (+ BACKGROUND)** — GPS speed detection. Without it, the “all 3 sensors” rule can’t work. User must choose “Allow all the time” for background driving detection.
* **SYSTEM_ALERT_WINDOW (Display over other apps)** — *Required* to show the block screen over any app while driving. Without this, eotr cannot block.
* **FOREGROUND_SERVICE + FOREGROUND_SERVICE_LOCATION** — keeps `DrivingDetectionService` alive.
* **POST_NOTIFICATIONS** — shows persistent “Protection active” notification (Android requires it for foreground services).
* **RECEIVE_BOOT_COMPLETED** — auto-restarts protection after reboot so rule is persistent.
* **REQUEST_IGNORE_BATTERY_OPTIMIZATIONS** — prevents Android from killing eotr in background (Doze).
* **BIND_ACCESSIBILITY_SERVICE (optional but recommended)** — strongest mode; prevents user from dismissing block via tricks. Play Store requires disclosure — provided in onboarding.
* **BIND_DEVICE_ADMIN (optional)** — enables `force-lock` policy if you provision as device owner.

---

## The hard truth about “unbreakable”

On modern Android (10–14), **no regular Play Store app is allowed to truly unbreakably prevent unlocking** — that would be ransomware. What eotr does is the maximum allowed:

* Foreground service that never stops
* Full-screen overlay (`SYSTEM_ALERT_WINDOW`) that re-appears 200ms after any attempt to leave it
* Accessibility service that watches for dismiss attempts
* Device Admin receiver for enterprise policy
* Boot receiver for persistence

A determined user can still break it by: booting into **Safe Mode**, or going to *Settings → Apps → eotr → Force Stop*, or revoking overlay permission. That’s by Android design.

**For 100% unbreakable:** provision eotr as a **Device Owner** (enterprise kiosk / Lock Task mode) via ADB:

```bash
adb shell dpm set-device-owner com.eotr.eyesontheroad/.EotrDeviceAdminReceiver
# then enable lock task in code — system will not allow exit without admin PIN
```

Instructions are in `Help → Device Owner mode` inside the app.

**Emergency calls are never blocked.** Tapping “Emergency Call” dials 911 via `ACTION_DIAL`, which Android always allows even on lock screens.

---

## Safety & Ethics notes

* **Passenger mode exists so passengers aren't stranded.** It shows a warning dialog but does NOT instantly unlock — you must still place the phone flat & still for 10s. This adds friction for drivers.
* **Not for use while driving by any occupant handling the phone.** Even passenger handling is risky — eotr is intentionally annoying.
* **You should not attempt to bypass your own safety.** eotr adds friction to save lives; it can't override human choice.
* **Test it safely:** Use `Test block screen (preview)` in the app while parked. Never test while driving.

---

## Delaware + next steps

You’re in New Castle, DE — great place to pilot: straight roads + I-95 corridor. Consider:

1. **Beta test with family:** install on 2–3 phones, drive around parking lot, verify 10s timer opens only when flat.
2. **Tune thresholds:** if eotr is too sensitive on bumpy roads, increase `GPS_STILL_MAX_MPS` to 1.0 m/s or `GYRO_STILL_MAX` to 0.18 in `StationaryDetector.kt`.
3. **Add Drive detection v2:** Use `ActivityRecognition` API (“in vehicle” confidence) as 4th signal.
4. **Icon polish:** The included `ic_otter_mascot.png` is your otter floating with phone — have a designer vectorize it to `ic_otter_mascot.xml` for crispness.

---

## License

MIT — use freely. If you save lives with it, tell us the otter story!

🦦 *Eyes on the road. Save the otter — and the driver.*
