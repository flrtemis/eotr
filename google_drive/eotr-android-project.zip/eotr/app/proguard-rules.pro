# Keep eotr classes
-keep class com.eotr.eyesontheroad.** { *; }
-dontwarn com.google.android.gms.**
