package com.eotr.eyesontheroad

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import java.util.concurrent.Executors

/**
 * Foreground service that implements the EOTR 10-second rule.
 * It fuses Accelerometer + Gyroscope + GPS and decides LOCK vs UNLOCK.
 */
class DrivingDetectionService : Service(), SensorEventListener {

    companion object {
        const val CHANNEL_ID = "eotr_protection"
        const val NOTIF_ID = 1001
        const val ACTION_START = "eotr.START"
        const val ACTION_STOP = "eotr.STOP"

        fun start(ctx: Context) {
            val i = Intent(ctx, DrivingDetectionService::class.java).apply { action = ACTION_START }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i)
            else ctx.startService(i)
        }
        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, DrivingDetectionService::class.java))
        }
    }

    private lateinit var sensorManager: SensorManager
    private var accelSensor: Sensor? = null
    private var gyroSensor: Sensor? = null

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationRequest: LocationRequest
    private var locationCallback: LocationCallback? = null

    private val detector = StationaryDetector()

    // Latest sensor values
    private var lastAx = 0f; private var lastAy = 0f; private var lastAz = 9.81f
    private var lastGx = 0f; private var lastGy = 0f; private var lastGz = 0f
    private var lastSpeedMps = 0f; private var lastAccuracyM = 999f

    private var isBlocking = false
    private val executor = Executors.newSingleThreadExecutor()

    // Polling loop: evaluate every 200ms
    private val handler = android.os.Handler(Looper.getMainLooper())
    private val evalRunnable = object : Runnable {
        override fun run() {
            evaluateAndAct()
            handler.postDelayed(this, 200)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        gyroSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(800L)
            .setWaitForAccurateLocation(false)
            .build()

        registerSensors()
        startLocationUpdates()
        handler.post(evalRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification(false, "Monitoring — will lock when moving"))
        // Persist that service was requested
        getSharedPreferences("eotr", MODE_PRIVATE).edit().putBoolean("service_wanted", true).apply()
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(evalRunnable)
        try { sensorManager.unregisterListener(this) } catch (_: Exception) {}
        try { locationCallback?.let { fusedLocationClient.removeLocationUpdates(it) } } catch (_: Exception) {}
        executor.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // --- Sensor callbacks ---
    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                lastAx = event.values[0]; lastAy = event.values[1]; lastAz = event.values[2]
            }
            Sensor.TYPE_GYROSCOPE -> {
                lastGx = event.values[0]; lastGy = event.values[1]; lastGz = event.values[2]
            }
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun registerSensors() {
        accelSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        gyroSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    private fun startLocationUpdates() {
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc: Location = result.lastLocation ?: return
                // getSpeed() may be 0 if not available; fallback to computed if needed
                lastSpeedMps = if (loc.hasSpeed()) loc.speed else 0f
                lastAccuracyM = if (loc.hasAccuracy()) loc.accuracy else 999f

                // Also consider getSpeedAccuracy if available (API 26+)
                // Store for detector
            }
        }
        try {
            // Permission check must have been done in MainActivity
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback!!, Looper.getMainLooper())
        } catch (e: SecurityException) {
            // Location permission not granted — we fail safe to BLOCKING? Actually without GPS we cannot fulfill "all 3" rule.
            // Safer: treat GPS as non-still until permission granted.
            lastSpeedMps = 99f
        }
    }

    private fun evaluateAndAct() {
        val accelMag = detector.computeAccelMagnitude(lastAx, lastAy, lastAz)
        val gyroMag = detector.computeGyroMagnitude(lastGx, lastGy, lastGz)
        val tilt = detector.computeTiltDegrees(lastAx, lastAy, lastAz)

        val snap = SensorSnapshot(
            accelMagnitude = accelMag,
            accelVariance = 0f, // computed inside detector via window
            gyroMagnitude = gyroMag,
            gpsSpeedMps = lastSpeedMps,
            gpsAccuracyM = lastAccuracyM,
            tiltDegrees = tilt
        )
        val decision = detector.update(snap)

        // Broadcast for UI
        val intent = Intent("eotr.STATUS").apply {
            setPackage(packageName)
            putExtra("accelStill", decision.isAccelStill)
            putExtra("gyroStill", decision.isGyroStill)
            putExtra("gpsStill", decision.isGpsStill)
            putExtra("level", decision.isLevel)
            putExtra("allStill", decision.allStill)
            putExtra("accelMag", accelMag)
            putExtra("gyroMag", gyroMag)
            putExtra("speed", lastSpeedMps)
            putExtra("tilt", tilt)
            putExtra("remaining", decision.remainingMsToUnlock)
            putExtra("duration", decision.stationaryDurationMs)
            putExtra("reason", decision.reason)
        }
        sendBroadcast(intent)

        // --- Enforcement logic ---
        // Unlock allowed ONLY if allStill == true (which already implies 10s elapsed)
        // Otherwise => BLOCK
        val shouldBlock = !decision.allStill

        // Update notification
        updateNotification(shouldBlock, decision)

        if (shouldBlock && !isBlocking) {
            isBlocking = true
            launchBlockScreen(decision)
        } else if (!shouldBlock && isBlocking) {
            isBlocking = false
            dismissBlockScreen()
        }
        // If already blocking, keep updating block screen via broadcast
        if (isBlocking) {
            sendBroadcast(Intent("eotr.BLOCK_UPDATE").apply {
                setPackage(packageName)
                putExtra("remaining", decision.remainingMsToUnlock)
                putExtra("reason", decision.reason)
                putExtra("speed", lastSpeedMps)
                putExtra("accelStill", decision.isAccelStill)
                putExtra("gpsStill", decision.isGpsStill)
                putExtra("gyroStill", decision.isGyroStill)
                putExtra("level", decision.isLevel)
            })
        }
    }

    private fun launchBlockScreen(decision: StationaryDecision) {
        val i = Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            putExtra("reason", decision.reason)
        }
        try {
            startActivity(i)
        } catch (e: Exception) {
            // If overlay fails, at least keep notification
        }
    }

    private fun dismissBlockScreen() {
        sendBroadcast(Intent("eotr.DISMISS_BLOCK").apply { setPackage(packageName) })
    }

    // --- Notification ---
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW).apply {
                description = getString(R.string.notif_channel_desc)
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(isBlocking: Boolean, detail: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABILITY
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, DrivingDetectionService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABILITY
        )
        val title = if (isBlocking) getString(R.string.notif_text_blocking) else getString(R.string.notif_title)
        val text = if (isBlocking) "Locked — place phone flat & still for 10s to unlock" else getString(R.string.notif_text)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_busy) // replace with otter icon after mipmap added
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$text\n$detail"))
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_delete, "Pause", stopIntent)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    private fun updateNotification(isBlocking: Boolean, decision: StationaryDecision) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try {
            nm.notify(NOTIF_ID, buildNotification(isBlocking, decision.reason))
        } catch (_: Exception) {}
    }
}
