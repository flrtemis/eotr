package com.eotr.eyesontheroad

import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * EOTR Core Rule Engine
 *
 * Philosophy: Eyes On The Road
 * - The device is ALLOWED to unlock ONLY after ALL THREE sensors agree
 *   the device is on a LEVEL surface and NOT MOVING for >= 10,000 ms.
 * - Otherwise, the device is considered DRIVING/MOVING -> BLOCKED.
 *
 * This implements your "wishful thinking" spec literally:
 * accelerometers + GPS + gyroscopic must ALL successfully determine stationary.
 *
 * Thresholds are conservative for safety.
 */
data class SensorSnapshot(
    val accelMagnitude: Float = 0f,          // m/s², should be ~9.81 when still
    val accelVariance: Float = 0f,           // variance of accel over window
    val gyroMagnitude: Float = 0f,           // rad/s
    val gpsSpeedMps: Float = 0f,             // m/s from Location.getSpeed()
    val gpsAccuracyM: Float = 999f,
    val tiltDegrees: Float = 90f,            // 0 = flat on back, 90 = vertical
    val timestampMs: Long = System.currentTimeMillis()
)

data class StationaryDecision(
    val isAccelStill: Boolean,
    val isGyroStill: Boolean,
    val isGpsStill: Boolean,
    val isLevel: Boolean,
    val allStill: Boolean,
    val stationaryDurationMs: Long,
    val remainingMsToUnlock: Long,
    val reason: String
)

class StationaryDetector {

    companion object {
        const val REQUIRED_STATIONARY_MS = 10_000L // Your spec: ten thousand ms

        // --- Thresholds (tuned for real-world driving) ---
        // Accelerometer: magnitude should be ~9.81 ± tolerance, and variance low
        const val ACCEL_GRAVITY = SensorManager.GRAVITY_EARTH // 9.80665
        const val ACCEL_TOLERANCE = 0.9f          // m/s² tolerance from 9.81
        const val ACCEL_VARIANCE_MAX = 0.35f      // low variance = not shaking

        // Gyroscope: very low angular velocity = not rotating/turning
        const val GYRO_STILL_MAX = 0.12f          // rad/s (~7 deg/s) - conservative

        // GPS: speed
        const val GPS_STILL_MAX_MPS = 0.5f        // m/s = 1.1 mph ≈ walking threshold
        const val GPS_MAX_ACCURACY_M = 30f        // ignore GPS if inaccurate

        // Level: tilt from horizontal
        const val LEVEL_MAX_TILT_DEG = 15f       // must be within 15° of flat
    }

    // Internal state: window for variance calculation
    private val accelWindow = ArrayDeque<Float>(20)
    private var stationaryStartMs: Long? = null
    private var lastDecision: StationaryDecision? = null

    /**
     * Call this on every sensor/GPS update (ideally 5-10 Hz)
     * Returns whether the 10s rule is satisfied (=> unlock allowed)
     */
    fun update(snapshot: SensorSnapshot): StationaryDecision {
        // ---- 1. Update variance window ----
        accelWindow.addLast(snapshot.accelMagnitude)
        if (accelWindow.size > 20) accelWindow.removeFirst()
        val variance = if (accelWindow.size >= 5) {
            val avg = accelWindow.average().toFloat()
            val v = accelWindow.map { (it - avg) * (it - avg) }.average().toFloat()
            v
        } else 99f

        // ---- 2. Evaluate each sensor ----
        val accelStill = isAccelerometerStill(snapshot.accelMagnitude, variance)
        val gyroStill = isGyroscopeStill(snapshot.gyroMagnitude)
        val gpsStill = isGpsStill(snapshot.gpsSpeedMps, snapshot.gpsAccuracyM)
        val level = isLevel(snapshot.tiltDegrees)

        val allStill = accelStill && gyroStill && gpsStill && level

        // ---- 3. Manage 10,000 ms timer ----
        val now = snapshot.timestampMs
        if (allStill) {
            if (stationaryStartMs == null) stationaryStartMs = now
        } else {
            stationaryStartMs = null
        }

        val duration = if (stationaryStartMs != null) now - stationaryStartMs!! else 0L
        val remaining = if (allStill) (REQUIRED_STATIONARY_MS - duration).coerceAtLeast(0) else REQUIRED_STATIONARY_MS

        val reason = buildReason(accelStill, gyroStill, gpsStill, level, variance, snapshot)

        val decision = StationaryDecision(
            isAccelStill = accelStill,
            isGyroStill = gyroStill,
            isGpsStill = gpsStill,
            isLevel = level,
            allStill = allStill && duration >= REQUIRED_STATIONARY_MS,
            stationaryDurationMs = duration,
            remainingMsToUnlock = remaining,
            reason = reason
        )
        lastDecision = decision
        return decision
    }

    fun isUnlockAllowed(): Boolean = lastDecision?.allStill == true

    fun reset() {
        stationaryStartMs = null
        accelWindow.clear()
        lastDecision = null
    }

    // ---- Individual sensor predicates ----

    private fun isAccelerometerStill(magnitude: Float, variance: Float): Boolean {
        val magnitudeOk = abs(magnitude - ACCEL_GRAVITY) < ACCEL_TOLERANCE
        val varianceOk = variance < ACCEL_VARIANCE_MAX
        return magnitudeOk && varianceOk
    }

    private fun isGyroscopeStill(mag: Float): Boolean {
        return mag < GYRO_STILL_MAX
    }

    private fun isGpsStill(speed: Float, accuracy: Float): Boolean {
        // If GPS accuracy is terrible, we don't trust it — but we also DON'T allow unlock on bad GPS
        // Conservative: if accuracy > threshold, treat as NOT still (fail-safe)
        if (accuracy > GPS_MAX_ACCURACY_M) {
            // Allow if speed is explicitly 0 and we have no fix? For safety, consider NOT still
            // But to avoid permanent lock in tunnels, we allow if speed==0 and accuracy poor
            // Here we implement: poor accuracy => require other sensors extra strict, but GPS alone fails open briefly
            // Choose fail-safe: GPS poor => not still
            return false
        }
        return speed < GPS_STILL_MAX_MPS
    }

    private fun isLevel(tiltDeg: Float): Boolean {
        // tilt 0 = flat, 90 = upright. We want flat within 15°
        return tiltDeg < LEVEL_MAX_TILT_DEG
    }

    private fun buildReason(
        accelStill: Boolean, gyroStill: Boolean, gpsStill: Boolean, level: Boolean,
        variance: Float, snap: SensorSnapshot
    ): String {
        if (accelStill && gyroStill && gpsStill && level) return "All sensors confirm stationary & level"
        val fails = mutableListOf<String>()
        if (!accelStill) fails.add("Accel moving (var=${String.format("%.2f", variance)})")
        if (!gyroStill) fails.add("Gyro rotating (${String.format("%.2f", snap.gyroMagnitude)} rad/s)")
        if (!gpsStill) fails.add("GPS moving (${String.format("%.1f", snap.gpsSpeedMps*3.6)} km/h)")
        if (!level) fails.add("Not level (${String.format("%.0f", snap.tiltDegrees)}° tilt)")
        return fails.joinToString(" • ")
    }

    // Helpers
    fun computeAccelMagnitude(ax: Float, ay: Float, az: Float): Float {
        return sqrt(ax*ax + ay*ay + az*az)
    }

    fun computeTiltDegrees(ax: Float, ay: Float, az: Float): Float {
        // Tilt from horizontal using accelerometer: angle between gravity vector and Z axis
        // Simplified: acos(az / magnitude) in degrees
        val mag = sqrt(ax*ax + ay*ay + az*az)
        if (mag == 0f) return 90f
        val cos = (az / mag).coerceIn(-1f, 1f)
        return Math.toDegrees(kotlin.math.acos(cos.toDouble())).toFloat()
    }

    fun computeGyroMagnitude(gx: Float, gy: Float, gz: Float): Float {
        return sqrt(gx*gx + gy*gy + gz*gz)
    }
}
