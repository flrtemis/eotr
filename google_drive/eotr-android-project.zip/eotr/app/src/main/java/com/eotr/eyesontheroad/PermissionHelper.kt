package com.eotr.eyesontheroad

import android.content.Context
import android.os.Build
import android.provider.Settings

object PermissionHelper {
    fun canDrawOverlays(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(ctx) else true
}
