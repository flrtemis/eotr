package com.eotr.eyesontheroad

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action in listOf(
                Intent.ACTION_BOOT_COMPLETED,
                "android.intent.action.QUICKBOOT_POWERON",
                Intent.ACTION_MY_PACKAGE_REPLACED
            )
        ) {
            val prefs = context.getSharedPreferences("eotr", Context.MODE_PRIVATE)
            val wanted = prefs.getBoolean("service_wanted", false)
            if (wanted) {
                // Restart foreground service after boot
                try {
                    DrivingDetectionService.start(context)
                } catch (_: Exception) {}
            }
        }
    }
}
