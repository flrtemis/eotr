package com.eotr.eyesontheroad

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.eotr.eyesontheroad.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        updatePermissionButtons()
        if (perms.values.all { it }) {
            // all granted, can start service if overlay also granted
            tryStartService()
        }
    }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != "eotr.STATUS") return
            val accelStill = intent.getBooleanExtra("accelStill", false)
            val gyroStill = intent.getBooleanExtra("gyroStill", false)
            val gpsStill = intent.getBooleanExtra("gpsStill", false)
            val level = intent.getBooleanExtra("level", false)
            val allStill = intent.getBooleanExtra("allStill", false)
            val accelMag = intent.getFloatExtra("accelMag", 0f)
            val gyroMag = intent.getFloatExtra("gyroMag", 0f)
            val speed = intent.getFloatExtra("speed", 0f)
            val tilt = intent.getFloatExtra("tilt", 0f)
            val remaining = intent.getLongExtra("remaining", 10000L)

            updateSensorPanel(accelStill, gyroStill, gpsStill, level, allStill, accelMag, gyroMag, speed, tilt, remaining)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClicks()
        updatePermissionButtons()
        // auto-register receiver for live updates
        val filter = IntentFilter("eotr.STATUS")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(statusReceiver, filter)
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionButtons()
    }

    override fun onDestroy() {
        try { unregisterReceiver(statusReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun setupClicks() {
        binding.btnLocation.setOnClickListener { requestLocationPerms() }
        binding.btnOverlay.setOnClickListener { requestOverlay() }
        binding.btnBattery.setOnClickListener { requestIgnoreBattery() }
        binding.btnAccessibility.setOnClickListener { openAccessibility() }
        binding.btnStartService.setOnClickListener {
            if (hasAllCriticalPerms()) {
                DrivingDetectionService.start(this)
                Toast.makeText(this, "🦦 eotr protection started — Eyes on the road!", Toast.LENGTH_SHORT).show()
                binding.btnStartService.text = getString(R.string.btn_permissions_granted)
                binding.btnStartService.isEnabled = false
            } else {
                Toast.makeText(this, getString(R.string.error_need_overlay), Toast.LENGTH_LONG).show()
                updatePermissionButtons()
            }
        }
        binding.btnTestBlock.setOnClickListener {
            startActivity(Intent(this, BlockActivity::class.java).apply {
                putExtra("testMode", true)
            })
        }
    }

    private fun updateSensorPanel(
        accelStill: Boolean, gyroStill: Boolean, gpsStill: Boolean, level: Boolean, allStill: Boolean,
        accelMag: Float, gyroMag: Float, speed: Float, tilt: Float, remaining: Long
    ) {
        binding.valAccel.text = String.format("%.2f m/s² %s", accelMag, if (accelStill) "✓ still" else "✗ moving")
        binding.valGyro.text = String.format("%.2f rad/s %s", gyroMag, if (gyroStill) "✓ still" else "✗ rotating")
        binding.valGps.text = String.format("%.1f m/s (%.1f mph) %s", speed, speed*2.23694f, if (gpsStill) "✓ stationary" else "✗ moving")
        binding.valLevel.text = String.format("%.0f° tilt %s", tilt, if (level) "✓ level" else "✗ not level")

        binding.dotAccel.setBackgroundResource(if (accelStill) R.drawable.dot_green else R.drawable.dot_red)
        binding.dotGyro.setBackgroundResource(if (gyroStill) R.drawable.dot_green else R.drawable.dot_red)
        binding.dotGps.setBackgroundResource(if (gpsStill) R.drawable.dot_green else R.drawable.dot_red)
        binding.dotLevel.setBackgroundResource(if (level) R.drawable.dot_green else R.drawable.dot_red)

        val progress = ((10000 - remaining).coerceIn(0, 10000) / 100).toInt()
        binding.progressStationary.setProgress(progress, true)
        binding.valTimer.text = String.format("%.1fs / 10.0s", (10000 - remaining)/1000f)

        if (allStill) {
            binding.chipStatus.text = getString(R.string.status_protected)
            binding.chipStatus.setBackgroundResource(R.drawable.bg_status_chip)
            binding.txtStatusDetail.text = getString(R.string.status_detail_stationary)
        } else if (remaining in 1..9999) {
            binding.txtStatusDetail.text = getString(R.string.status_detail_waiting)
            binding.chipStatus.text = "WAITING ${remaining/1000}s"
            binding.chipStatus.setBackgroundResource(R.drawable.bg_status_chip)
        } else {
            binding.txtStatusDetail.text = getString(R.string.status_detail_moving)
            binding.chipStatus.text = "BLOCKING — MOVING"
            binding.chipStatus.setBackgroundResource(R.drawable.bg_status_chip) // could be red
        }
    }

    private fun updatePermissionButtons() {
        val locGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        binding.btnLocation.text = if (locGranted) "✓ Granted" else "Allow"
        binding.btnLocation.isEnabled = !locGranted
        binding.btnLocation.alpha = if (locGranted) 0.6f else 1f

        val overlayGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(this) else true
        binding.btnOverlay.text = if (overlayGranted) "✓ Granted" else "Allow"
        binding.btnOverlay.isEnabled = !overlayGranted
        binding.btnOverlay.alpha = if (overlayGranted) 0.6f else 1f

        val pm = getSystemService(PowerManager::class.java)
        val batteryOk = pm.isIgnoringBatteryOptimizations(packageName)
        binding.btnBattery.text = if (batteryOk) "✓ Granted" else "Allow"
        binding.btnBattery.isEnabled = !batteryOk
        binding.btnBattery.alpha = if (batteryOk) 0.6f else 1f

        // Accessibility check is heuristic — user must verify
        // We can't reliably detect without querying, but we attempt
        val accEnabled = isAccessibilityEnabled()
        binding.btnAccessibility.text = if (accEnabled) "✓ Enabled" else "Enable"
        binding.btnAccessibility.alpha = if (accEnabled) 0.6f else 1f

        val allGood = locGranted && overlayGranted
        binding.btnStartService.isEnabled = allGood
        if (allGood) binding.btnStartService.text = getString(R.string.btn_enable_protection)
    }

    private fun requestLocationPerms() {
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) perms.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissionLauncher.launch(perms.toTypedArray())
    }

    private fun requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(intent)
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
        }
    }

    private fun requestIgnoreBattery() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun openAccessibility() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find 'eotr' and turn it ON for strongest blocking.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {}
    }

    private fun hasAllCriticalPerms(): Boolean {
        val loc = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val overlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(this) else true
        return loc && overlay
    }

    private fun tryStartService() {
        if (hasAllCriticalPerms()) {
            DrivingDetectionService.start(this)
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains(packageName)
    }
}
