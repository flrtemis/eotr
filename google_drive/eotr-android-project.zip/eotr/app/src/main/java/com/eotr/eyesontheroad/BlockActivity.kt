package com.eotr.eyesontheroad

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.eotr.eyesontheroad.databinding.ActivityBlockBinding

/**
 * Full-screen block screen shown when DrivingDetectionService determines
 * the device is MOVING. It cannot be dismissed until 10s stationary rule passes.
 *
 * It respects emergency calls and offers a passenger mode (with warning).
 * Back button and outside touches are NOT allowed to dismiss while blocking.
 */
class BlockActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBlockBinding
    private var isTestMode = false
    private var isDismissAllowed = false

    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            when (intent?.action) {
                "eotr.BLOCK_UPDATE" -> {
                    val remaining = intent.getLongExtra("remaining", 10000L)
                    val reason = intent.getStringExtra("reason") ?: ""
                    val accelStill = intent.getBooleanExtra("accelStill", false)
                    val gpsStill = intent.getBooleanExtra("gpsStill", false)
                    val gyroStill = intent.getBooleanExtra("gyroStill", false)
                    val level = intent.getBooleanExtra("level", false)
                    updateUi(remaining, reason, accelStill, gpsStill, gyroStill, level)
                }
                "eotr.DISMISS_BLOCK" -> {
                    // Service says we're now stationary 10s -> unlock allowed
                    isDismissAllowed = true
                    finish()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBlockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isTestMode = intent.getBooleanExtra("testMode", false)

        // Make it truly full-screen and show over lock screen
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        // Prevent screenshots in block mode (optional safety)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)

        setupClicks()

        if (isTestMode) {
            binding.txtBlockTimer.text = "TEST MODE — preview of block screen"
            binding.txtBlockCountdown.text = "Tap Back to exit test"
            binding.txtSensorSummary.text = "Test: All sensors simulated as moving"
            // Auto-dismiss after 5s in test mode, otherwise requires real service signal
            binding.root.postDelayed({ if (!isFinishing) finish() }, 5000)
        }

        val filter = IntentFilter().apply {
            addAction("eotr.BLOCK_UPDATE")
            addAction("eotr.DISMISS_BLOCK")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(updateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(updateReceiver, filter)
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(updateReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun setupClicks() {
        binding.btnEmergency.setOnClickListener {
            // Emergency dialer — never blocked
            try {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:911"))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } catch (e: Exception) {
                startActivity(Intent(Intent.ACTION_DIAL))
            }
        }
        binding.btnPassenger.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.block_passenger_dialog_title))
                .setMessage(getString(R.string.block_passenger_dialog_msg))
                .setPositiveButton("I understand — place flat & wait") { d, _ -> d.dismiss() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun updateUi(remaining: Long, reason: String, accelStill: Boolean, gpsStill: Boolean, gyroStill: Boolean, level: Boolean) {
        binding.txtBlockCountdown.text = if (remaining > 0) String.format("%.1fs still needed", remaining/1000f) else "Unlocking..."
        binding.progressBlock.progress = ((10000 - remaining).coerceIn(0, 10000) * 100 / 10000)
        binding.txtSensorSummary.text = buildString {
            append(if (accelStill) "Accel: ✓ " else "Accel: ✗ ")
            append(if (gyroStill) "Gyro: ✓ " else "Gyro: ✗ ")
            append(if (gpsStill) "GPS: ✓ " else "GPS: ✗ ")
            append(if (level) "Level: ✓ " else "Level: ✗ ")
            append(" • $reason")
        }
    }

    // --- Lockdown behavior ---
    override fun onBackPressed() {
        if (isTestMode || isDismissAllowed) super.onBackPressed()
        else {
            // Do nothing — keep eyes on road. Vibrate feedback maybe
            binding.txtBlockCountdown.text = "Keep eyes on the road — phone is moving!"
            binding.root.performHapticFeedback(android.view.HapticFeedbackConstants.REJECT)
        }
    }

    override fun onUserLeaveHint() {
        // User tried to go home — re-bring to front if still blocking and not allowed to dismiss
        if (!isDismissAllowed && !isTestMode) {
            // Re-launch self
            val i = Intent(this, BlockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            }
            startActivity(i)
        } else super.onUserLeaveHint()
    }
}
