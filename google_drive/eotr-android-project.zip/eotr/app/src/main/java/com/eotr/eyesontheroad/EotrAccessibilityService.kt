package com.eotr.eyesontheroad

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Optional but strongest enforcement layer.
 * When enabled, it can detect if user force-closes the block screen and re-show it
 * while the driving condition is still true. It does NOT block system UI maliciously;
 * it simply ensures the safety overlay isn't dismissed by third-party launchers.
 *
 * Modern Play Store policies require a clear disclosure for accessibility use —
 * see MainActivity onboarding text.
 */
class EotrAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We intentionally keep this minimal to comply with policy.
        // The heavy lifting is in DrivingDetectionService; this service just
        // guarantees eotr can't be trivially bypassed via accessibility APIs.
    }

    override fun onInterrupt() {}
}
