# Build Guide — eotr APK

## Quick build (Android Studio)

1. Download the project zip (see Workspace files).
2. Unzip to `~/eotr`
3. Open Android Studio → Open → select `eotr`
4. Wait for Gradle Sync to finish (first time ~2-3 min, downloads dependencies)
5. Create an emulator or connect a real device (USB debugging ON)
6. Press ▶️ Run

## Where is the APK?

After Run:
```
eotr/app/build/outputs/apk/debug/app-debug.apk    # debug APK, ~8-12 MB
eotr/app/build/outputs/apk/release/app-release-unsigned.apk  # release
```

Share via email, Drive, AirDrop, or `adb install`.

## Command-line build

Requires Android SDK installed (you can install via Android Studio → SDK Manager).

```bash
# First time: generate wrapper if missing
cd eotr
gradle wrapper --gradle-version 8.6

./gradlew assembleDebug
# output: app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease   # needs signing config
```

### Signing a release APK

Generate a keystore once:

```bash
keytool -genkey -v -keystore eotr-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias eotr
```

Then add to `app/build.gradle` inside `android { }`:

```gradle
signingConfigs {
    release {
        storeFile file("../eotr-release.jks")
        storePassword "YOUR_PASSWORD"
        keyAlias "eotr"
        keyPassword "YOUR_PASSWORD"
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled true
        shrinkResources true
    }
}
```

Then:

```bash
./gradlew assembleRelease
# → app/build/outputs/apk/release/app-release.apk (signed, ready to sideload or Play Store)
```

## Testing checklist (do this parked!)

- [ ] Install APK, open eotr, grant Location (Always Allow), Overlay, Battery
- [ ] Tap Enable Protection → notification appears “🦦 eotr — Protection active”
- [ ] Watch live sensor panel — all dots green when phone flat on table, still
- [ ] Timer goes 10s → chip says PROTECTION ACTIVE
- [ ] Pick up phone and walk → dots red, block screen appears within ~0.5s
- [ ] Place flat & still 10s → block screen auto-dismisses
- [ ] Test Emergency Call button → dialer opens (cancel before calling)
- [ ] Reboot phone → notification returns automatically (BootReceiver)
- [ ] Test Passenger Mode dialog appears but still requires 10s still

## Troubleshooting

**“Display over other apps” won’t allow?**  
On some skins (Xiaomi, OnePlus, Samsung) also enable “Appear on top” + “Autostart” in system battery settings.

**GPS always red?**  
Go outside, open Google Maps to get a GPS fix, then return. Indoor GPS accuracy >30m will show red by design (fail-safe).

**Service killed after a while?**  
Enable “Ignore Battery Optimization” (the app will prompt). On Samsung: Settings → Battery → Unrestricted for eotr.

**Block screen not showing?**  
Check you granted overlay. On Android 14+, you must manually toggle it per app.

**Want unbreakable?**  
See README → Device Owner mode via `adb shell dpm set-device-owner ...` — only for dedicated/test devices.
