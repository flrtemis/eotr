# How the 10,000 ms (10-second) Rule Works

Your spec:

> “set a persistent, unbreakable RULE that inhibits the screen ... IF the mobile phone has successfully identified (only after successfully determining via all 3; accelerometers, GPS, and gyroscopic capabilities) that it is on a level surface and not moving for a minimum of at least ten thousand milliseconds or more.”

## Interpretation

Literal reading: “inhibit IF stationary 10s” would lock the phone *when parked* — opposite of safety!  
**Implemented meaning (life-saving):** *inhibit UNLESS stationary+level for 10s* — i.e., lock when driving, unlock only when proven parked.

Code documents this flip explicitly so future maintainers understand intent.

## State diagram

```
         ┌─────────────────────────────────────────────────────┐
         │           ALL SENSORS STILL + LEVEL?                 │
         │   accelStill && gyroStill && gpsStill && level      │
         └──────────┬────────────────────────────────┬─────────┘
                    │ YES (all green)                │ NO (any red)
                    ▼                                ▼
          ┌─────────────────┐              ┌──────────────────┐
          │ Start/continue  │              │ RESET timer to 0 │
          │ stationaryStart │              │ stationStart=null│
          │ timer           │              │ BLOCKED          │
          └────────┬────────┘              └──────────────────┘
                   │
                   ▼
          duration = now - start
          if duration >= 10,000ms → UNLOCKED
          else → BLOCKED (countdown shown)
```

## Sensor details

**Accelerometer:**
- `magnitude = sqrt(ax²+ay²+az²)` — should ≈9.81 when not accelerating
- `variance` over last 20 samples — handheld driving = high variance
- Threshold: `|mag - 9.81| < 0.9` AND `variance < 0.35`

**Gyroscope:**
- `magnitude = sqrt(gx²+gy²+gz²)` — car turning = rotation
- Threshold: `<0.12 rad/s` (~7°/s) — very still

**GPS:**
- `speed = Location.getSpeed()` in m/s
- Threshold: `<0.5 m/s` AND accuracy `<30m`
- If accuracy poor → treat as NOT still (fail-safe — blocks rather than allows)

**Level:**
- `tilt = acos(az / mag)` in degrees — 0° = flat, 90° = vertical
- Threshold: `<15°` — must be on table/dash, not held to ear

## Why “level surface”?

Your spec required level surface — brilliant addition:
- Prevents phone in pocket/purse from counting as “stationary” (it’s vertical/shaky)
- Forces intentional placement: driver must put phone down flat, not just hold still for a second
- Creates *friction* — you can’t quickly glance while “holding still” at red light while still holding wheel

## Timing

- Evaluation loop: every 200 ms (5 Hz) — fast enough to catch sudden movement
- GPS updates: every 800-1000 ms (high accuracy)
- History window: 20 accel samples (~4s) for variance
- Unlock grace: none — must be 10 continuous seconds; 1ms of movement resets to 0

## Fail-safes

- If GPS permission denied → speed = 99 → always blocked (forces user to grant)
- If sensor missing (some cheap devices) → that sensor = not still → blocked
- Emergency dialer bypasses everything (Android guarantees this)

## Tuning (edit StationaryDetector.kt)

If too strict (locks on speed bumps):
```kotlin
const val GPS_STILL_MAX_MPS = 0.8f  // was 0.5
const val GYRO_STILL_MAX = 0.18f    // was 0.12
const val LEVEL_MAX_TILT_DEG = 22f  // was 15
```

If too lenient (unlocks while creeping in traffic):
```kotlin
const val GPS_STILL_MAX_MPS = 0.3f
const val REQUIRED_STATIONARY_MS = 15_000L  // 15s
```

