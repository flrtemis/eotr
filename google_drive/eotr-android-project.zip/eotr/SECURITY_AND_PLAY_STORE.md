# Security, Privacy & Play Store Notes for eotr

## Privacy — what eotr collects

**Nothing leaves the phone.**

- GPS speed is read via `FusedLocationProviderClient` but **never uploaded**, never cached to server, never shared. It lives only in RAM to compute `isGpsStill`.
- Accelerometer/gyroscope data is ephemeral (20-sample window) and discarded.
- No analytics, no ads, no tracking. You can verify: `grep -r "http" app/src` returns nothing.

If you publish to Play Store, declare:

> Location → “used for safety feature to detect driving; not collected or shared.”

Add a `privacy-policy.html` stating this, host on GitHub Pages, link in Play Console.

## Why Play Store might flag eotr

Apps that “block” other apps are sensitive. To pass review:

1. **Onboarding disclosure:** MainActivity already explains why overlay + accessibility is needed with a clear consent button. Keep it.
2. **Accessibility justification:** In Play Console → Policy → Accessibility, write:
   > “eotr uses AccessibilityService only to ensure the driving safety overlay cannot be bypassed while vehicle motion is detected, preventing distracted driving. It does not collect or observe user interaction.”
3. **Do not hide the passenger bypass:** Play Store reviewer will check. Document that passenger mode exists but requires 10s stationary.
4. **Emergency dialer must work:** Verified — BlockActivity uses `ACTION_DIAL`, not restricted.

## Permissions that trigger review

- `SYSTEM_ALERT_WINDOW` → user must manually grant; cannot auto-grant. Explain clearly (done).
- `ACCESS_BACKGROUND_LOCATION` → requires in-app prompt + Play Console video showing why background needed (driving detection while app in background). Provide screen recording of onboarding.
- `Accessibility` → most sensitive; provide video + description. Optional — app works without it, just less “unbreakable.” Consider offering two APK flavors: `standard` (no a11y) and `max` (with a11y) so you can publish standard first.

## “Unbreakable” disclaimer

Never claim 100% unbreakable in Play Store listing — reviewer will reject for deceptive claim + potential malware. Use language like:

> “eotr creates strong friction to prevent texting while driving. On standard Android, it can be paused via system settings — enterprise Device Owner mode is required for kiosk-level enforcement.”

This is honest and passes.

## Data safety form (example)

- Location: collected? Yes (on-device only), Shared? No
- Sensors: collected? Yes (on-device only)
- Personal info: No
- Encryption in transit: N/A (no transit)
- Data deletion: uninstall deletes everything

## Child safety

eotr is family-friendly (otter mascot). If you target kids, note it’s a parental safety tool, not a game.

